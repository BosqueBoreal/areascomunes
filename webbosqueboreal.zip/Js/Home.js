console.log ('hola mundo');
const nocambia ="erik"
let cambia = "@erik"